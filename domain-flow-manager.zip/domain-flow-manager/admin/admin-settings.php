<?php
// This file will handle the admin settings page of the plugin.
function domain_flow_manager_admin_settings_page() {
    // Here you will create the HTML output for the page, and handle saving of settings.
    // ...
}
