<?php
// This file will contain utility functions that can be used throughout the plugin
